ACELLARZECK AI VIDEO STUDIO — PROYEK ANDROID V2.1

Ini adalah proyek sumber Android Studio (WebView APK wrapper), bukan APK siap instal. Isi aplikasi web V2.0 disertakan di app/src/main/assets.

MEMBUAT APK DENGAN HP ANDROID + GITHUB ACTIONS (TANPA KOMPUTER):
1. Buat repository baru di GitHub dengan nama ACELLARZECK-AI-VIDEO-STUDIO. Pilih Public atau Private sesuai keinginan.
2. Unduh ZIP proyek ini. Di repository, pilih Add file > Upload files, lalu unggah ZIP proyek dan ubah nama file unggahan menjadi android-project.zip jika perlu.
3. Di repository, pilih Add file > Create new file. Beri nama persis: .github/workflows/build-apk.yml
4. Salin isi workflow build-apk.yml dari folder .github/workflows di paket proyek ini ke file baru tersebut, lalu tekan Commit changes.
5. Buka tab Actions. Pilih workflow "Build ACELLARZECK AI VIDEO STUDIO APK" dan jalankan Run workflow. Jika push otomatis memicu build, tunggu proses selesai.
6. Jika status build hijau/berhasil, buka hasil run dan unduh artifact bernama ACELLARZECK-AI-VIDEO-STUDIO-debug-apk.
7. Ekstrak artifact ZIP di HP, lalu buka app-debug.apk untuk memasang. Android mungkin meminta izin instal aplikasi dari sumber ini.

Jika lebih mudah, setelah repository dibuat, minta panduan langkah demi langkah. Jangan kirim kata sandi, token, atau kode verifikasi GitHub.

CATATAN APLIKASI:
- Minimum Android 6.0 (API 23), target SDK 35.
- WebView mendukung JavaScript, penyimpanan lokal, dan pemilihan gambar dari perangkat.
- Mesin AI text-to-video/image-to-video dan AI voice belum tersambung. Aplikasi saat ini menjalankan antarmuka dan penyusun prompt.
