plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.acellarzeck.aivideostudio"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.acellarzeck.aivideostudio"
        minSdk = 23
        targetSdk = 35
        versionCode = 21
        versionName = "2.1"
    }
}
